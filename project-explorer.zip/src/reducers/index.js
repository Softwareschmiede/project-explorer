import { combineReducers } from 'redux';
import utils from './utils';

export default combineReducers({
  isNewProjectModalOpen: utils
});